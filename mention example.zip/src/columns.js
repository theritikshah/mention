const columns = [
  {
    Type: "column",
    Val: "pass_id",
    Display: "PASS ID",
  },
  {
    Type: "column",
    Val: "pclass_id",
    Display: "PCLASS ID",
  },
  {
    Type: "column",
    Val: "name",
    Display: "NAME",
  },
  {
    Type: "column",
    Val: "age",
    Display: "Age",
  },
];

export default columns;
