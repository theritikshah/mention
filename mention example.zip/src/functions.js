const functions = [
  {
    type: "function",
    name: "SUM",
    value: "sum",
  },
  {
    type: "function",
    name: "AVERAGE",
    value: "average",
  },
  {
    type: "function",
    name: "MAXIMUM",
    value: "maximum",
  },
  {
    type: "function",
    name: "MINIMUM",
    value: "minimum",
  },
  {
    type: "function",
    name: "UNIQUE COUNT",
    value: "nuniquecount",
  },
  {
    type: "function",
    name: "COUNT",
    value: "count",
  },
];

export default functions;
